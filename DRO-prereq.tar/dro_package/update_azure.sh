#!/bin/sh
# currently written for ubuntu based systems

# Get the IP as input
if [ ! -z $1 ] && [ $1 = "dev" ]; then
   echo "******************         Running in dev mode           *****************"
fi
echo "Welcome to NetApp DRO Installation Wizard"
echo ""
echo "This Wizard will update DRO 2.0.1 on your system"
echo "NOTE: Ensure you are using an Ubuntu 20.04 OS"
echo ""
echo "Enter the host IP (In the format 10.10.10.10)"
read HOST_IP


##################      Check for dependencies on Host System       ##################
echo "Verifying if all dependencies are installed"
if ! command -v jq >/dev/null 2>&1; then
   apt-get update -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "Failed to update apt packages"
      exit 2
   fi
   echo "[ ] Installing jq"
   apt-get install jq -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "[X] Failed to install jq"
      exit 2
   else
      echo "[✔] Installed jq"
   fi
else
   echo "[✔] jq already installed"
fi

if [ -x "$(command -v docker)" ]; then
   echo "[✔] docker.io already installed"
else
   echo "[ ] Installing docker.io"
   apt-get install docker.io -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "[X] Failed to install docker.io"
      exit 2
   else
      echo "[✔] Installed docker.io"
   fi
fi

if [ -x "$(command -v docker-compose)" ]; then
   echo "[✔] docker-compose already installed"
else
   echo "[ ] Installing docker-compose"
   apt-get install docker-compose -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "Failed to install docker-compose"
      exit 2
   else
      echo "[✔] Installed docker-compose"
   fi
fi

if [ -x "$(command -v openssl)" ]; then
   echo "[✔] openssl already installed"
else
   echo "[ ] Installing openssl"
   apt-get install openssl -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "[X] Failed to install openssl"
      exit 2
   else
      echo "[✔] Installed openssl"
   fi
fi

echo "All dependencies installed"

##################      Extract and update config files      ##################

echo "Uncompressing dro_agent"
tar -xf dro_agent.tar
if ! [ $? -eq 0 ]; then
   echo "Failed to untar dro_agent.tar"
   exit 2
fi

echo "Uncompressing dro_app"
tar -xf dro_app.tar
if ! [ $? -eq 0 ]; then
   echo "Failed to untar dro_app.tar"
   exit 2
fi

# DB Config
OLD_UUID=`jq -r '.app.secretKey' /opt/netapp/dro_agent/dro-discovery/config/config.json`
if ! [ $? -eq 0 ]; then
   echo "Failed to get secret key for dro-discovery config file"
   exit 2
fi

ivString=`jq -r '.app.ivString' /opt/netapp/dro_app/svc/dro-recovery/config/config.json`
if ! [ $? -eq 0 ]; then
   echo "Failed to get ivString for dro-recovery config file"
   exit 2
fi

keyBytes=`jq -r '.app.keyBytes' /opt/netapp/dro_app/svc/dro-recovery/config/config.json`
if ! [ $? -eq 0 ]; then
   echo "Failed to get keyBytes for dro-recovery config file"
   exit 2
fi

dbEndpoint=`jq -r '.adapters.mongo.endPoint' /opt/netapp/dro_app/svc/dro-recovery/config/config.json`
if ! [ $? -eq 0 ]; then
   echo "Failed to get DB endpoint for dro-recovery config file"
   exit 2
fi

systemPwd=`jq -r '.app.systemAccounts | to_entries[0].value.password' /opt/netapp/dro_app/svc/dro-setup/config/config.json`
if ! [ $? -eq 0 ]; then
   echo "Failed to get system password for dro-setup config file"
   exit 2
fi

#recovery
cat dro_app/svc/dro-recovery/config/config.json | jq -r --arg secretKey "$OLD_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-recovery config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-recovery config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-recovery/config/config.json | jq -r --arg ivString "$ivString" '.app.ivString |= $ivString' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-recovery config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-recovery config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-recovery/config/config.json | jq -r --arg keyBytes "$keyBytes" '.app.keyBytes |= $keyBytes' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-recovery config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-recovery config file"
   exit 2
fi

#setup
cat dro_app/svc/dro-setup/config/config.json | jq -r --arg secretKey "$OLD_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-setup config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | jq -r --arg ivString "$ivString" '.app.ivString |= $ivString' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-setup config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | jq -r --arg keyBytes "$keyBytes" '.app.keyBytes |= $keyBytes' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-setup config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | jq -r --arg systemPwd "$systemPwd" '.app.systemAccounts."f342aca3-bf30-40a8-b50b-446f3e90b94e".password |= $systemPwd' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for dro-setup config file"
   exit 2
fi

#tenant
cat dro_app/svc/tenant/config/config.json | jq -r --arg secretKey "$OLD_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for tenant config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for tenant config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/tenant/config/config.json | jq -r --arg ivString "$ivString" '.app.ivString |= $ivString' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for tenant config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for tenant config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/tenant/config/config.json | jq -r --arg keyBytes "$keyBytes" '.app.keyBytes |= $keyBytes' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for tenant config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for tenant config file"
   exit 2
fi

#workflow
cat dro_app/svc/workflow/config/config.json | jq -r --arg secretKey "$OLD_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for workflow config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for workflow config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/workflow/config/config.json | jq -r --arg ivString "$ivString" '.app.ivString |= $ivString' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for workflow config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for workflow config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/workflow/config/config.json | jq -r --arg keyBytes "$keyBytes" '.app.keyBytes |= $keyBytes' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for workflow config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key for workflow config file"
   exit 2
fi

#ui
mv dro_app/svc/dro-ui/env/env-config.js /opt/netapp/dro_app/svc/dro-ui/env/env-config.js
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-ui config file"
   exit 2
fi

#discovery
cat dro_agent/dro-discovery/config/config.json | jq -r --arg secretKey "$OLD_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-discovery config file with secret key"
   exit 2
fi

mv config.json /opt/netapp/dro_agent/dro-discovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-discovery config file"
   exit 2
fi

#execution
cat dro_agent/dro-execution/config/config.json | jq -r --arg secretKey "$OLD_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-discovery config file with secret key"
   exit 2
fi

mv config.json /opt/netapp/dro_agent/dro-execution/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-execution config file"
   exit 2
fi

#compliance
mv dro_agent/dro-compliance/config/config.json /opt/netapp/dro_agent/dro-compliance/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-compliance config file"
   exit 2
fi

#monitoring
mkdir -p /opt/netapp/dro_agent/monitoring/config
if ! [ $? -eq 0 ]; then
   echo "Failed to create monitoring config folder"
   exit 2
fi

mv dro_agent/monitoring/config/config.json /opt/netapp/dro_agent/monitoring/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update monitoring config file"
   exit 2
fi

mv dro_agent/monitoring/config/index.js /opt/netapp/dro_agent/monitoring/config/index.js
if ! [ $? -eq 0 ]; then
   echo "Failed to update monitoring index file"
   exit 2
fi

#stepWorker
mv dro_app/svc/workflow/lib/stepWorker/config/config.json /opt/netapp/dro_app/svc/workflow/lib/stepWorker/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update stepWorker config file"
   exit 2
fi

#messages
mv dro_agent/dro-compliance/messages/messages.json /opt/netapp/dro_agent/dro-compliance/messages/messages.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-compliance messages file"
   exit 2
fi

mkdir -p /opt/netapp/dro_agent/monitoring/messages
if ! [ $? -eq 0 ]; then
   echo "Failed to create monitoring messages folder"
   exit 2
fi

mv dro_agent/monitoring/messages/messages.json /opt/netapp/dro_agent/monitoring/messages/messages.json
if ! [ $? -eq 0 ]; then   
   echo "Failed to update dro-compliance messages file"
   exit 2
fi

mv dro_agent/monitoring/messages/index.js /opt/netapp/dro_agent/monitoring/messages/index.js
if ! [ $? -eq 0 ]; then   
   echo "Failed to update dro-compliance messages index file"
   exit 2
fi

mv dro_agent/dro-discovery/messages/messages.json /opt/netapp/dro_agent/dro-discovery/messages/messages.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-discovery messages file"
   exit 2
fi

mv dro_agent/dro-execution/messages/messages.json /opt/netapp/dro_agent/dro-execution/messages/messages.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-execution messages file"
   exit 2
fi

mv dro_app/svc/dro-recovery/messages/messages.json /opt/netapp/dro_app/svc/dro-recovery/messages/messages.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-recovery messages file"
   exit 2
fi

mv dro_app/svc/dro-setup/messages/messages.json /opt/netapp/dro_app/svc/dro-setup/messages/messages.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update dro-setup messages file"
   exit 2
fi

mv dro_app/svc/tenant/messages/messages.json /opt/netapp/dro_app/svc/tenant/messages/messages.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update tenant messages file"
   exit 2
fi

mv dro_app/svc/workflow/messages/messages.json /opt/netapp/dro_app/svc/workflow/messages/messages.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update workflow messages file"
   exit 2
fi

docker_repo="psairam284/dro-internal:"
if [ ! -z $1 ] && [ $1 = "dev" ]; then
  find /opt/netapp/dro_agent/.env -type f -exec sed -i -e "/^DOCKER_REPO=/s@=.*@=$docker_repo@" {} \;
  find /opt/netapp/dro_app/.env -type f -exec sed -i -e "/^DOCKER_REPO=/s@=.*@=$docker_repo@" {} \;
  find /opt/netapp/dro_nginx/.env -type f -exec sed -i -e "/^DOCKER_REPO=/s@=.*@=$docker_repo@" {} \;
fi

#update docker-compose file
mv dro_agent/docker-compose.yml /opt/netapp/dro_agent/docker-compose.yml
if ! [ $? -eq 0 ]; then
   echo "Failed to update docker-compose file"
   exit 2
fi


rm -rf dro_app/
rm -rf dro_agent/

##################      Set IP Address      ##################


echo "Setting Server IP"
WHITELIST=`jq --compact-output --null-input '$ARGS.positional' --args -- "https://$HOST_IP"`

#recovery
cat /opt/netapp/dro_app/svc/dro-recovery/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for dro-recovery config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for dro-recovery config file"
   exit 2
fi

#setup
sudo cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for dro-setup config file"
   exit 2
fi

#tenant
sudo cat /opt/netapp/dro_app/svc/tenant/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for tenant config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for tenant config file"
   exit 2
fi

#monitoring
sudo cat /opt/netapp/dro_agent/monitoring/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for monitoring config file"
   exit 2
fi

mv config.json /opt/netapp/dro_agent/monitoring/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for monitoring config file"
   exit 2
fi

#workflow
sudo cat /opt/netapp/dro_app/svc/workflow/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for workflow config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for workflow config file"
   exit 2
fi

#ui
sed -i /opt/netapp/dro_app/svc/dro-ui/env/env-config.js -e "s/REACT_APP_RUNTIME_SERVER_IP.*/REACT_APP_RUNTIME_SERVER_IP: '${HOST_IP}',/" /opt/netapp/dro_app/svc/dro-ui/env/env-config.js
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for dro-ui config file"
   exit 2
fi

sed -i /opt/netapp/dro_app/svc/dro-ui/env/env-config.js -e "s/REACT_APP_RUNTIME_SOURCE_PLATFORM.*/REACT_APP_RUNTIME_SOURCE_PLATFORM: 'azure',/" /opt/netapp/dro_app/svc/dro-ui/env/env-config.js
if ! [ $? -eq 0 ]; then
   echo "Failed to update source site options for dro-ui config file"
   exit 2
fi

sed -i /opt/netapp/dro_app/svc/dro-ui/env/env-config.js -e "s/REACT_APP_RUNTIME_TARGET_PLATFORM.*/REACT_APP_RUNTIME_TARGET_PLATFORM: 'azure',/" /opt/netapp/dro_app/svc/dro-ui/env/env-config.js
if ! [ $? -eq 0 ]; then
   echo "Failed to update destination site options for dro-ui config file"
   exit 2
fi


cat > /opt/netapp/dro_nginx/conf.d/default.conf <<EOF
server {
    listen 443 ssl;
    #listen [::]:443 ssl;
    include snippets/self-signed.conf;
    #include snippets/ssl-params.conf;
    #listen       80;
    #listen  [::]:80;
    proxy_read_timeout 600;
    proxy_connect_timeout 600;
    proxy_send_timeout 600;
    server_name  localhost;

    client_max_body_size 50M;

    #access_log  /var/log/nginx/host.access.log  main;

    #location / {
    #    root   /usr/share/nginx/html;
    #    index  index.html index.htm;
    #}

    location / {
        proxy_pass http://dro-ui:3000;
    }

    location /api/tenant {
        proxy_pass http://tenant:3698;
    }

    location /api/setup {
        proxy_pass http://dro-setup:3700;
    }

    location /api/recovery {
        proxy_pass http://dro-recovery:3704;
    }

    location /api/discovery {
        proxy_pass http://dro-discovery:3701;
    }

    location /api/compliance {
        proxy_pass http://dro-compliance:3703;
    }

    location /api/execution {
        proxy_pass http://dro-execution:3702;
    }

    location /api/workflow {
        proxy_pass http://workflow:3699;
    }

    location /api/monitoring {
        proxy_pass http://monitoring:3697;
    }



    #error_page  404              /404.html;

    # redirect server error pages to the static page /50x.html
    #
    #error_page   500 502 503 504  /50x.html;
    #location = /50x.html {
    #    root   /usr/share/nginx/html;
    #}

    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #
    #location ~ \.php$ {
    #    proxy_pass   http://127.0.0.1;
    #}

    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #
    #location ~ \.php$ {
    #    root           html;
    #    fastcgi_pass   127.0.0.1:9000;
    #    fastcgi_index  index.php;
    #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
    #    include        fastcgi_params;
    #}

    # deny access to .htaccess files, if Apache's document root
    # concurs with nginx's one
    #
    #location ~ /\.ht {
    #    deny  all;
    #}
}

server {
    listen 80;
    #listen [::]:80;

    server_name "${HOST_IP}";

    proxy_read_timeout 600;
    proxy_connect_timeout 600;
    proxy_send_timeout 600;

    client_max_body_size 50M;

    return 308 https://\$server_name\$request_uri;
}
EOF
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address for dro-nginx config file"
   exit 2
fi

echo "Server IP set"

#DB Secret
echo "Setting Database Configuration"

sed -i "s|mongodb://user:dbpassword@dro-mongo:27017|$dbEndpoint|g" /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password for dro-recovery config file"
   exit 2
fi

sed -i "s|mongodb://user:dbpassword@dro-mongo:27017|$dbEndpoint|g" /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password for dro-setup config file"
   exit 2
fi

sed -i "s|mongodb://user:dbpassword@dro-mongo:27017|$dbEndpoint|g" /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password for tenant config file"
   exit 2
fi

sed -i "s|mongodb://user:dbpassword@dro-mongo:27017|$dbEndpoint|g" /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password for workflow config file"
   exit 2
fi

TENANT_ID=$(cat /opt/netapp/dro_app/tenant_id.txt | tr -d '\r\n' | sed 's/\//\\\//g')
echo "Tenant ID: $TENANT_ID"

sed -i 's/f342aca3-bf30-40a8-b50b-446f3e90b94e/'"$TENANT_ID"'/g' /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update Tenant ID in dro-setup config"
   exit 2
fi

echo "Database Configuration set"

##################      Stop Existing Service Docker containers      ##################

echo "*****    Updating current environment:    *****"
cd /opt/netapp/dro_nginx/
docker-compose down
if ! [ $? -eq 0 ]; then
   echo "Failed to bring down nginx"
   exit 2
fi

cd /opt/netapp/dro_app/
docker-compose down
if ! [ $? -eq 0 ]; then
   echo "Failed to bring down app"
   exit 2
fi

cd /opt/netapp/dro_agent/
docker-compose down
if ! [ $? -eq 0 ]; then
   echo "Failed to bring down agent"
   exit 2
fi

##################      Pipe setup for monitoring      ##################

echo "Setting up log monitoring pipe"
mkdir -p /opt/netapp/dro_agent/monitoring/logs
if ! [ $? -eq 0 ]; then
   echo "Failed to create monitoring logs directory"
   exit 2
fi

if [ ! -e /opt/netapp/dro_agent/monitoring/logs/tmp-pipe ]; then
    mkfifo /opt/netapp/dro_agent/monitoring/logs/tmp-pipe
    if ! [ $? -eq 0 ]; then
      echo "Failed to create pipe"
      exit 2
   fi
   echo "pipe created successfully"
else
    echo "pipe already exists."
fi

echo "setting up pipe script"
if [ ! -e /opt/netapp/dro_agent/monitoring/logs/pipeSetup.sh ]; then
   printf '#!/bin/bash\nexec > /opt/netapp/dro_agent/monitoring/logs/pipeSetup.log 2>&1\necho "pipeSetup.sh started"\nwhile true; do\n  cmd=$(cat /opt/netapp/dro_agent/monitoring/logs/tmp-pipe)\n  echo "Executing command: $cmd"\n  eval "$cmd"\n  echo "Command executed: $cmd"\ndone &\n' > /opt/netapp/dro_agent/monitoring/logs/pipeSetup.sh
   if ! [ $? -eq 0 ]; then
      echo "Failed to create pipeSetup script"
      exit 2
   fi
   echo "pipeSetup script created successfully"
else
    echo "pipeSetup script already exists."
fi

echo "updating pipe script permissions"
chmod +x /opt/netapp/dro_agent/monitoring/logs/pipeSetup.sh
if ! [ $? -eq 0 ]; then
   echo "Failed to update permissions for pipeSetup script"
   exit 2
fi

cd /opt/netapp/dro_agent/monitoring/logs/
if ! [ $? -eq 0 ]; then
   echo "Failed to navigate to monitoring logs directory"
   exit 2
fi

echo "checking if pipe script is running"
if ! pgrep -f "pipeSetup.sh" > /dev/null; then
    echo "executing pipe script"
    nohup sh pipeSetup.sh &
    if ! [ $? -eq 0 ]; then
       echo "Failed to execute pipeSetup script"
       exit 2
    fi
else
    echo "pipe script is already running"
fi

echo "checking if crontab entry exists"
if ! crontab -l | grep -q "/opt/netapp/dro_agent/monitoring/logs/pipeSetup.sh"; then
   echo "updating crontab with pipe script"
   (crontab -l 2>/dev/null; echo "@reboot /opt/netapp/dro_agent/monitoring/logs/pipeSetup.sh") | crontab -
   if ! [ $? -eq 0 ]; then
      echo "Failed to update crontab with pipeSetup script"
      exit 2
   fi
else
   echo "script exists in the crontab"
fi

echo "pipe setup completed successfully"

##################      Remove Service Docker container images      ##################

echo "Cleaning up old docker images"
if [ ! -z $1 ] && [ $1 = "dev" ]; then
   docker rmi -f psairam284/dro-internal:dro-setup > /dev/null
   docker rmi -f psairam284/dro-internal:dro-execution > /dev/null
   docker rmi -f psairam284/dro-internal:dro-recovery > /dev/null
   docker rmi -f psairam284/dro-internal:dro-ui > /dev/null
   docker rmi -f psairam284/dro-internal:dro-workflow > /dev/null
   docker rmi -f psairam284/dro-internal:dro-tenant > /dev/null
   docker rmi -f psairam284/dro-internal:dro-discovery > /dev/null
   docker rmi -f psairam284/dro-internal:dro-compliance > /dev/null
   docker rmi -f psairam284/dro-internal:dro_mongo > /dev/null
   docker rmi -f psairam284/dro-internal:dro_nginx > /dev/null
   docker rmi -f psairam284/dro-internal:dro-monitoring > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-setup > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-execution > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-recovery > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-ui > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-workflow > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-tenant > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-discovery > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-compliance > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro_mongo > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro_nginx > /dev/null
   # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-monitoring > /dev/null
else
   docker rmi -f netapp/dro:dro-setup > /dev/null
   docker rmi -f netapp/dro:dro-execution > /dev/null
   docker rmi -f netapp/dro:dro-recovery > /dev/null
   docker rmi -f netapp/dro:dro-ui > /dev/null
   docker rmi -f netapp/dro:dro-workflow > /dev/null
   docker rmi -f netapp/dro:dro-tenant > /dev/null
   docker rmi -f netapp/dro:dro-discovery > /dev/null
   docker rmi -f netapp/dro:dro-compliance > /dev/null
   docker rmi -f netapp/dro:dro_mongo > /dev/null
   docker rmi -f netapp/dro:dro_nginx > /dev/null
   docker rmi -f netapp/dro:dro-monitoring > /dev/null
fi
echo "Cleanup complete"

##################      Run Latest Service Docker container images      ##################

echo "*****    Initializing DRO agent and app services    *****"

cd /opt/netapp/dro_agent/
docker-compose up -d
if ! [ $? -eq 0 ]; then
   echo "Failed to bring up Agent"
   exit 2
else
   echo "*****    Agent is up and running    *****"
fi

cd /opt/netapp/dro_app/
docker-compose up -d
if ! [ $? -eq 0 ]; then
   echo "Failed to run bring up App"
   exit 2
else
   echo "*****    App is up and running    *****"
fi

cd /opt/netapp/dro_nginx/
docker-compose up -d
if ! [ $? -eq 0 ]; then
   echo "Failed to bring up Nginx"
   exit 2
else
   echo "*****    Nginx is up and running    *****"
fi

echo "Update complete. DRO is now running. Access the service at https://${HOST_IP}"