docker ps > docker-ps.txt
docker images > docker-images.txt
docker info > docker-info.txt

docker logs tenant > tenant-logs.txt
docker logs workflow > workflow-logs.txt
docker logs dro-nginx > dro-nginx-logs.txt
docker logs dro-recovery > dro-recovery-logs.txt
docker logs dro-setup > dro-setup-logs.txt
docker logs dro-mongo > dro-mongo-logs.txt
docker logs dro-ui > dro-ui-logs.txt
docker logs dro-execution > dro-execution-logs.txt
docker logs dro-compliance > dro-compliance-logs.txt
docker logs dro-recovery > dro-discovery-logs.txt
docker logs monitoring > monitoring-logs.txt

tar -czf dro-docker-command-output.tar docker-ps.txt docker-images.txt docker-info.txt tenant-logs.txt monitoring-logs.txt workflow-logs.txt dro-nginx-logs.txt dro-recovery-logs.txt dro-setup-logs.txt dro-mongo-logs.txt dro-ui-logs.txt dro-execution-logs.txt dro-compliance-logs.txt dro-discovery-logs.txt
tar -czf dro-troubleshoot.tar /opt/netapp/ /var/lib/docker/containers/ dro-docker-command-output.tar

rm -f docker-ps.txt
rm -f docker-images.txt
rm -f docker-info.txt

rm -f tenant-logs.txt
rm -f workflow-logs.txt
rm -f monitoring-logs.txt
rm -f dro-nginx-logs.txt
rm -f dro-recovery-logs.txt
rm -f dro-setup-logs.txt
rm -f dro-mongo-logs.txt
rm -f dro-ui-logs.txt
rm -f dro-execution-logs.txt
rm -f dro-compliance-logs.txt
rm -f dro-discovery-logs.txt

rm dro-docker-command-output.tar

echo -n "Troubleshoot file dro_troubleshoot.tar has been created and can be found at "
pwd